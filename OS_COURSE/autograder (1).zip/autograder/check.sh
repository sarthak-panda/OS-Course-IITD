#!/bin/bash


submission=$1
csv_file=$2
rm -rf ./test_dir
rm -rf test_dir
mkdir ./test_dir
rm -rf ./test_dir/*

echo $submission

fileNameRegex_double="assignment3_easy_[0-9]{4}[A-Za-z]{2,3}[0-9]{4,5}.tar.gz"
fileNameRegex_single="assignment3_easy_[0-9]{4}[A-Za-z]{2,3}[0-9]{4,5}_[0-9]{4}[A-Za-z]{2,3}[0-9]{4,5}.tar.gz"

if ! [[ $submission =~ $fileNameRegex_double || $submission =~ $fileNameRegex_single ]]; then
    echo "File doesn't match the naming convention"
    exit
fi

echo "Setting the test directory"
tar -xzf "$submission" -C ./test_dir


cp inject/memlayout.h inject/Makefile inject/sh.c ./test_dir
cp inject/memtest0.c inject/memtest0.sh ./test_dir
cp inject/memtest1.c inject/memtest1.sh ./test_dir
cp inject/memtest2.c inject/memtest2.sh ./test_dir
cp inject/ctrl-I.sh ./test_dir
cp inject/adaptive.sh ./test_dir


cd ./test_dir || exit
chmod +x *


expect -f ctrl-I.sh "$submission" "$csv_file"
expect -f adaptive.sh "$submission" "$csv_file"
expect -f memtest0.sh "$submission" "$csv_file"
expect -f memtest1.sh "$submission" "$csv_file"
expect -f memtest2.sh "$submission" "$csv_file"


