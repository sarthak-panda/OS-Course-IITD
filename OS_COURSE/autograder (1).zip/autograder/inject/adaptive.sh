#!/usr/bin/expect -f

set force_conservative 0  ;# set to 1 to force conservative mode even if
			  ;# script wasn't run conservatively originally
if {$force_conservative} {
	set send_slow {1 .1}
	proc send {ignore arg} {
		sleep .1
		exp_send -s -- $arg
	}
}

set timeout 30
set passed true;
set submission_name [lindex $argv 0]
set csv_file [lindex $argv 1]

spawn /bin/sh
expect "$ "

set result [catch {
    # startup
    puts "STARTUP"
    send "make clean\r"
    sleep 2
    send "make qemu-nox\r"
    expect {
        "init: starting sh" {}
        timeout {set passed false; error "Failed : XV6 does not boot"}
    }
    sleep 2

    # echo 
    puts "TESTING ECHO"
    send "echo Hello1\r"
    sleep 2
    expect {
        "Hello1" {}
        timeout {set passed false; error "Failed : Echo not works"}
    }

    # Memtest
    puts "TESTING MEMTEST0"
    send "memtest0\r"
    sleep 2

    # Checking some of the (Threshold, Npg) pairs
    expect {
        "Current Threshold = 100, Swapping 4 pages" {}
        timeout {set passed false; error "Failed : Incorrect threshold and swapped out pages. First pair should be (100:4)"}
    }
    expect {
        "Current Threshold = 81, Swapping 6 pages" {}
        timeout {set passed false; error "Failed : Incorrect threshold and swapped out pages. Third pair should be (81:6)"}
    }
    expect {
        "Memtest Passed" {}
        timeout {set passed false; error "Failed : Swapping not implemented properly"}
    }
    sleep 2
} errMsg]
sleep 2

# Write results to CSV regardless of pass/fail
set fp [open "../$csv_file" a]
if {$result != 0} {
    puts $fp "$submission_name,adaptive-pair,$passed,$errMsg"
} else  {
    puts $fp "$submission_name,adaptive-pair,$passed,NO ERROR"
}
close $fp

# finishing test
send "\x01"; send "x"
expect "QEMU: Terminated\r"
expect "$ "
send "exit\r"
expect eof
