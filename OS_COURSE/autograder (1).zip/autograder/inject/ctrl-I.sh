#!/usr/bin/expect -f

set force_conservative 0  ;# set to 1 to force conservative mode even if
			  ;# script wasn't run conservatively originally
if {$force_conservative} {
	set send_slow {1 .1}
	proc send {ignore arg} {
		sleep .1
		exp_send -s -- $arg
	}
}

set timeout 30
set passed true;
set submission_name [lindex $argv 0]
set csv_file [lindex $argv 1]

spawn /bin/sh
expect "$ "



set result [catch {
    # startup
    puts "STARTUP"
    send "make clean\r"
    sleep 2
    send "make qemu-nox\r"
    expect {
        "init: starting sh" {}
        timeout {set passed false; error "Failed : XV6 does not boot"}
    }

    sleep 2

    # echo 
    puts "TESTING ECHO"
    send "echo Hello1\r"
    sleep 2
    expect {
        "Hello1" {}
        timeout {set passed false; error "Failed : Echo not works"}
    }

    puts "TESTING CTRL + I"
    send "\x09"
    sleep 2

    expect {
        "Ctrl+I is detected by xv6" {}
        timeout {set passed false; error "Failed : Wrong Format <Ctrl+I is detected by xv6>"}
    }

    expect {
        "PID NUM_PAGES" {}
        timeout {set passed false; error "Failed : Wrong Format <PID NUM_PAGES>"}
    }

    expect {
        "1 3" {}
        timeout {set passed false; error "Failed : Wrong user space pages for init process. Should be 3."}
    }

    expect {
        "2 4" {}
        timeout {set passed false; error "Failed : Wrong user space pages for sh process. Should be 4."}
    }

    puts "CTRL + I gives correct output for PID 1"

    sleep 2
} errMsg]
sleep 2

# Write results to CSV regardless of pass/fail
set fp [open "../$csv_file" a]
if {$result != 0} {
    puts $fp "$submission_name,ctrl-I,$passed,$errMsg"
} else  {
    puts $fp "$submission_name,ctrl-I,$passed,NO ERROR"
}
close $fp

# finishing test
send "\x01"; send "x"
expect "QEMU: Terminated\r"
expect "$ "
send "exit\r"
expect eof


